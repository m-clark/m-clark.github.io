install.packages(c('tidyverse','lavaan', 'semPlot', 'semTools', 'mediation', 'bnlearn', 'igraph'))

# IF YOU ARE ON THE LAB COMPUTER, CLICK OKAY ON THE POP UP WINDOW