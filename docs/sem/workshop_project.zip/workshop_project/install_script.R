install.packages(c('rio', 'tidyverse','lavaan', 'semPlot', 'semTools', 'mediation', 'bnlearn', 'igraph', 'psych'))

# IF YOU ARE ON THE LAB COMPUTER, CLICK OKAY ON THE POP UP WINDOW