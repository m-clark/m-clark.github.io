# Useful shortcuts

*If using a mac typically it will be Cmd instead of Ctrl, but not always

Open a new R script: Ctrl+Shft+N
Run line or selection: Ctrl+Enter  (selection only needed for multiple lines)
Rerun previous: Ctrl+Shft+P


# Using R

Avoid typing anything at the console

Most of your initial errors will be typos.  Use the autocomplete so this will not be an issue.


# To install a package

At the console:

```
install.packages('packageName')
```

Or Click on Packages tab/Install and work from there.


# To use a package

In your script or at the console:

```
library(packageName)
```

# Packages needed

- haven (import Stata file)
- lavaan


If you use a lab machine for the workshop, attempting to install a package will prompt you to do so in a 'personal' library.  Do that. The prompt is usually a pop-under window! This means you'll see it on your taskbar but it won't be visible like a pop-up window until you click it. 


# Others used for content in workshop

- dplyr
- tidyverse
- mediation
- psych
- bnlearn
- d3heatmap
- semTools
- semPlots